int comp(const void *p1, const void *p2, char *t);
void bsort(void *a, int nmem, int size, int (*comp)(const void *, const void *, char *), char *);
void swap(void *x, void *y, int size);
