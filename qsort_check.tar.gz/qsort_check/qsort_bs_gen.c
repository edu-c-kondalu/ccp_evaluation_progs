#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int cmpstringp(const void *p1, const void *p2, char *);
int comp(const void *p1, const void *p2, char *t);
void bsort(void *a, int nmem, int size, int (*comp)(const void *, const void *, char *), char *);
void swap(void *x, void *y, int size);

int main()
{
  char a[20][30]={"xyz","def","Edu","Hari","CFC","CMRIT","Edukondalu","Helloworld!"};
  int b[20]={1, 3 , 100, 4, 23, 12, 25, 40};
  float c[20]={1.4, 3.2 , 10.0, 40.4, 23.6, 12.1, 25.9, 45.0};
  char type[20];
  int m,n,i;
  m=8;
  n=30;
  
 printf("Enter the type of the data: INT, CHAR, FLOAT\n");
 scanf("%s", type); 

 printf("Before Qsort:\n");
 if(strcmp(type, "CHAR")==0)
 {
	 for(i=0;i<m;i++)
		 printf("%s\t",a[i]);
	 
	 printf("\n");
	 bsort(a,m,n,comp,type);
	 
	 printf("After Qsort:\n");
	 for(i=0;i<m;i++)
	 	printf("%s\t",a[i]);

	 printf("\n");
 } else if(strcmp(type, "INT")==0)
 {
 	n=sizeof(int);
	for(i=0;i<m;i++)
		 printf("%d\t",b[i]);
	 
	printf("\n");
	bsort(b,m,n,comp,type);
	
	 printf("After Qsort:\n");
	 for(i=0;i<m;i++)
	 printf("%d\t",b[i]);

	 printf("\n");

 } else if(strcmp(type, "FLOAT")==0)
 {
 
  	n=sizeof(float);
  	for(i=0;i<m;i++)
		 printf("%f\t",c[i]);
	 
	printf("\n");
	
 	bsort(c,m,n,comp,type);
 	
	 printf("After Qsort:\n");
	 for(i=0;i<m;i++)
	 printf("%f\t",c[i]);

	 printf("\n");
 }
 
 return 0;
}


