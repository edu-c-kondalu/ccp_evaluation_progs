#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "sort.h"

int comp(const void *p1, const void *p2, char *type)
{
    /*The actual arguments to this function are "pointers to
       pointers to char", but strcmp(3) arguments are "pointers
       to char", hence the following cast plus dereference*/
    //printf("Inside compare, %s \t %s\n", (char *) p1, (char *) p2);
    if(strcmp(type, "CHAR")==0)
    {
    	return strcmp((char *)p1,(char *) p2);
    } else if(strcmp(type, "INT")==0)
    {
    	if(*(int *)p1>*(int *) p2)
    		return 1;
    	else
    		return 0;
    } else if(strcmp(type, "FLOAT")==0)
    {
    	if(*(float *)p1>*(float *) p2)
    		return 1;
    	else
    		return 0;
    }
    
    return 0;
}

void bsort(void *a, int nmem, int size, int (*comp)(const void *, const void *, char *), char *type)
{
   int i,j;
   
   printf("Inside bsort\n");
   for(i=0;i<nmem-1;i++)
   {
	   	for(j=0;j<nmem-i-1;j++)
	   	{
	   		if(comp(a+(j*size), a+(j+1)*size, type)>0)
	 	    {
	 	    	swap(a+(j*size), a+(j+1)*size, size);
			}
		}
 	}

 	//for(int i=0;i<nmem;i++)
	//	printf("%d\t",*((int *)(a)+i));
}

void swap(void *x, void *y, int size)
{
   void *temp = (void *)malloc(size);
   //temp =(void *)malloc(size+1);
   
   memcpy(temp,x, size);
   memcpy(x, y, size);
   memcpy(y, temp, size);
}
